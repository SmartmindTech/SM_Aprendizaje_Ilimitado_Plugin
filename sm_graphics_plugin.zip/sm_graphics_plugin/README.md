# SM_Moodle_Graphic_Layer_Plugin

## Introduction
This is the project to develop a graphic layer for a Standard (non-IOMAD) Moodle. This project intends to provide a better layout and style to Moodle, in order to make it more intuitive for SmartMind interests.
