<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Post-installation script — deploys and activates the SmartMind theme.
 *
 * The theme files are bundled inside this plugin under theme_smartmind/.
 * On install/upgrade, they are copied to /theme/smartmind/ and activated.
 *
 * @package    local_sm_graphics_plugin
 * @copyright  2026 SmartMind Technologies
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Runs after the plugin is installed for the first time.
 *
 * @return bool
 */
function xmldb_local_sm_graphics_plugin_install() {
    local_sm_graphics_plugin_deploy_theme();
    local_sm_graphics_plugin_activate_theme();
    return true;
}

/**
 * Copy the bundled theme_smartmind/ directory to /theme/smartmind/.
 */
function local_sm_graphics_plugin_deploy_theme() {
    global $CFG;

    $source = $CFG->dirroot . '/local/sm_graphics_plugin/theme_smartmind';
    $dest   = $CFG->dirroot . '/theme/smartmind';

    if (!is_dir($source)) {
        return;
    }

    local_sm_graphics_plugin_copy_directory($source, $dest);
}

/**
 * Activate the SmartMind theme.
 */
function local_sm_graphics_plugin_activate_theme() {
    global $CFG;

    $themeversionfile = $CFG->dirroot . '/theme/smartmind/version.php';
    if (!file_exists($themeversionfile)) {
        return;
    }

    if (get_config('core', 'theme') !== 'smartmind') {
        set_config('theme', 'smartmind');
        theme_reset_all_caches();
    }
}

/**
 * Recursively copy a directory.
 *
 * @param string $source Source directory path.
 * @param string $dest   Destination directory path.
 */
function local_sm_graphics_plugin_copy_directory(string $source, string $dest) {
    if (!is_dir($dest)) {
        mkdir($dest, 0755, true);
    }

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $item) {
        $target = $dest . DIRECTORY_SEPARATOR . $iterator->getSubPathname();
        if ($item->isDir()) {
            if (!is_dir($target)) {
                mkdir($target, 0755, true);
            }
        } else {
            copy($item->getPathname(), $target);
        }
    }
}
