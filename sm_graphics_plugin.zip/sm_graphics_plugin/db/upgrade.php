<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Upgrade script — deploys and activates the SmartMind theme on every version bump.
 *
 * @package    local_sm_graphics_plugin
 * @copyright  2026 SmartMind Technologies
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Runs when the plugin version is bumped.
 *
 * @param int $oldversion The previous version of the plugin.
 * @return bool
 */
function xmldb_local_sm_graphics_plugin_upgrade($oldversion) {
    require_once(__DIR__ . '/install.php');
    local_sm_graphics_plugin_deploy_theme();
    local_sm_graphics_plugin_activate_theme();
    return true;
}
