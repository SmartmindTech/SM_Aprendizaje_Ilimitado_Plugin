<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * SM Graphic Layer Plugin - English language strings.
 *
 * @package    local_sm_graphics_plugin
 * @copyright  2026 SmartMind Technologies
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// Plugin identity.
$string['pluginname']       = 'SM Graphic Layer';
$string['privacy:metadata'] = 'The SM Graphic Layer plugin does not store any personal data.';

// Admin settings — master toggle.
$string['enabled']          = 'Enable SM Graphic Layer';
$string['enabled_desc']     = 'Turn the visual overlay layer on or off site-wide. When disabled, Moodle renders normally with no changes from this plugin.';

// Admin settings — colors section.
$string['colors_heading']       = 'Brand Colors';
$string['color_primary']        = 'Primary color';
$string['color_primary_desc']   = 'Main brand color used for buttons, links, and accents. Use hex format, e.g. #0f6cbf';
$string['color_header_bg']      = 'Header background color';
$string['color_header_bg_desc'] = 'Background color of the top navigation bar. Use hex format, e.g. #1a1f35';
$string['color_sidebar_bg']     = 'Sidebar background color';
$string['color_sidebar_bg_desc']= 'Background color of the side navigation panel. Use hex format, e.g. #ffffff';

// Admin settings — logo section.
$string['logo_heading']     = 'Logo';
$string['logo_url']         = 'Logo URL';
$string['logo_url_desc']    = 'Full URL to the logo image shown in the header. Leave blank to use the default Moodle site logo.';

// Admin settings — plugin updates.
$string['update_heading']     = 'Plugin Updates';
$string['update_button']      = 'Check for updates';
$string['update_button_desc'] = 'Opens the Moodle admin page to check for available plugin updates.';

// Welcome page.
$string['welcome_title']      = 'Welcome';
$string['welcome_heading']    = 'Welcome to SmartMind';
