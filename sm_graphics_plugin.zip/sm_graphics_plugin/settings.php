<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * SM Graphic Layer Plugin - admin settings page.
 *
 * Accessible at: Site Administration → Plugins → Local plugins → SM Graphic Layer
 *
 * @package    local_sm_graphics_plugin
 * @copyright  2026 SmartMind Technologies
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// Local plugins must create their own settings page and register it manually.
// ($settings is not pre-created for local plugins the way it is for blocks/modules.)
$settings = new admin_settingpage(
    'local_sm_graphics_plugin',
    get_string('pluginname', 'local_sm_graphics_plugin')
);
$ADMIN->add('localplugins', $settings);

if ($ADMIN->fulltree) {
    global $CFG;

    // -----------------------------------------------------------------------
    // Master toggle
    // -----------------------------------------------------------------------
    $settings->add(new admin_setting_configcheckbox(
        'local_sm_graphics_plugin/enabled',
        get_string('enabled', 'local_sm_graphics_plugin'),
        get_string('enabled_desc', 'local_sm_graphics_plugin'),
        1  // Default: enabled.
    ));

    // -----------------------------------------------------------------------
    // Brand colors
    // -----------------------------------------------------------------------
    $settings->add(new admin_setting_heading(
        'local_sm_graphics_plugin/colors_heading',
        get_string('colors_heading', 'local_sm_graphics_plugin'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_sm_graphics_plugin/color_primary',
        get_string('color_primary', 'local_sm_graphics_plugin'),
        get_string('color_primary_desc', 'local_sm_graphics_plugin'),
        '#0f6cbf',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configtext(
        'local_sm_graphics_plugin/color_header_bg',
        get_string('color_header_bg', 'local_sm_graphics_plugin'),
        get_string('color_header_bg_desc', 'local_sm_graphics_plugin'),
        '#1a1f35',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configtext(
        'local_sm_graphics_plugin/color_sidebar_bg',
        get_string('color_sidebar_bg', 'local_sm_graphics_plugin'),
        get_string('color_sidebar_bg_desc', 'local_sm_graphics_plugin'),
        '#ffffff',
        PARAM_TEXT
    ));

    // -----------------------------------------------------------------------
    // Logo
    // -----------------------------------------------------------------------
    $settings->add(new admin_setting_heading(
        'local_sm_graphics_plugin/logo_heading',
        get_string('logo_heading', 'local_sm_graphics_plugin'),
        ''
    ));

    $settings->add(new admin_setting_configtext(
        'local_sm_graphics_plugin/logo_url',
        get_string('logo_url', 'local_sm_graphics_plugin'),
        get_string('logo_url_desc', 'local_sm_graphics_plugin'),
        '',
        PARAM_URL
    ));

    // -----------------------------------------------------------------------
    // Plugin updates
    // -----------------------------------------------------------------------
    $settings->add(new admin_setting_heading(
        'local_sm_graphics_plugin/update_heading',
        get_string('update_heading', 'local_sm_graphics_plugin'),
        '<a href="' . $CFG->wwwroot . '/admin/index.php?cache=0&confirmplugincheck=0" class="btn btn-primary">'
        . get_string('update_button', 'local_sm_graphics_plugin') . '</a>'
        . '<p class="text-muted mt-2">' . get_string('update_button_desc', 'local_sm_graphics_plugin') . '</p>'
    ));
}
