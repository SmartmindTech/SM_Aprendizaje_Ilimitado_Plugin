<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * SmartMind Theme - portfolio layout.
 *
 * Clean full-width layout with sidebar, no block regions.
 *
 * @package    theme_smartmind
 * @copyright  2026 SmartMind Technologies
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

global $CFG, $OUTPUT, $PAGE;

// Build sidebar context.
$sidebarcontext = [
    'menulinks' => [
        ['icon' => 'fa-home',       'label' => 'Dashboard',  'url' => $CFG->wwwroot . '/my/'],
        ['icon' => 'fa-graduation-cap', 'label' => 'My Courses', 'url' => $CFG->wwwroot . '/my/courses.php'],
        ['icon' => 'fa-calendar',   'label' => 'Calendar',   'url' => $CFG->wwwroot . '/calendar/view.php'],
        ['icon' => 'fa-envelope',   'label' => 'Messages',   'url' => $CFG->wwwroot . '/message/index.php'],
    ],
];

// Mark the active link.
$currenturl = $PAGE->url->out(false);
foreach ($sidebarcontext['menulinks'] as &$link) {
    $link['active'] = (strpos($currenturl, $link['url']) !== false);
}
unset($link);

?>
<?php echo $OUTPUT->doctype(); ?>
<html <?php echo $OUTPUT->htmlattributes(); ?>>
<head>
    <title><?php echo $OUTPUT->page_title(); ?></title>
    <link rel="shortcut icon" href="<?php echo $OUTPUT->favicon(); ?>" />
    <?php echo $OUTPUT->standard_head_html(); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body <?php echo $OUTPUT->body_attributes(); ?>>

<?php echo $OUTPUT->standard_top_of_body_html(); ?>

<div id="page-wrapper" class="d-flex">

    <?php echo $OUTPUT->render_from_template('theme_smartmind/sidebar', $sidebarcontext); ?>

    <div id="page" class="flex-grow-1">
        <div id="page-content" class="p-3">
            <div id="region-main-box">
                <section id="region-main">
                    <?php echo $OUTPUT->main_content(); ?>
                </section>
            </div>
        </div>

        <footer id="page-footer" class="p-3">
            <?php echo $OUTPUT->standard_footer_html(); ?>
        </footer>
    </div>
</div>

<?php echo $OUTPUT->standard_end_of_body_html(); ?>

</body>
</html>
