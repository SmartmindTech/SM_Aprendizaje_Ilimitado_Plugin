<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * SmartMind Theme - SCSS callback functions.
 *
 * @package    theme_smartmind
 * @copyright  2026 SmartMind Technologies
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Returns the main SCSS content for the theme.
 *
 * Loads Boost's SCSS as the base so all of Boost's styles are inherited.
 *
 * @param theme_config $theme The theme config object.
 * @return string SCSS content.
 */
function theme_smartmind_get_main_scss_content($theme) {
    return theme_boost_get_main_scss_content($theme);
}

/**
 * Returns the pre-SCSS content (variables, etc.).
 *
 * @param theme_config $theme The theme config object.
 * @return string Pre-SCSS content.
 */
function theme_smartmind_get_pre_scss($theme) {
    return '';
}

/**
 * Returns extra SCSS content appended after Boost's SCSS.
 *
 * This is where SmartMind customizations go — they override Boost's defaults.
 *
 * @param theme_config $theme The theme config object.
 * @return string Extra SCSS content.
 */
function theme_smartmind_get_extra_scss($theme) {
    global $CFG;

    $scss = '';
    $scssfile = $CFG->dirroot . '/theme/smartmind/scss/custom.scss';
    if (is_readable($scssfile)) {
        $scss = file_get_contents($scssfile);
    }

    return $scss;
}
