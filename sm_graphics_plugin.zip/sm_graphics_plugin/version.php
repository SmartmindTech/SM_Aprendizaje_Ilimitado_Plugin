<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Plugin version and other meta-data.
 *
 * @package    local_sm_graphics_plugin
 * @copyright  2026 SmartMind Technologies
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_sm_graphics_plugin';
$plugin->version = 2026031302;  // YYYYMMDDXX format.
$plugin->requires = 2022112800; // Moodle 4.1+
$plugin->maturity = MATURITY_ALPHA;
$plugin->release = '1.0.0';  // MATURITY_ALPHA, MATURITY_BETA, MATURITY_RC, MATURITY_STABLE

// GitHub update server - allows automatic update notifications.
// Point to the raw update.xml file in the GitHub repository.
$plugin->updateserver = 'https://raw.githubusercontent.com/SmartmindTech/SM_Moodle_Graphic_Layer_Plugin/main/update.xml';