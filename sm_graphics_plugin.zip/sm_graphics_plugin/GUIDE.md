# Complete Guide: SmartMind Moodle Plugin + Theme

**Two components:**
- `local_sm_graphics_plugin` — functionality (enrollment API, custom pages, settings, updates)
- `theme_smartmind` — visuals (layouts, sidebar, SCSS styling)

**Audience:** Developer with no PHP/frontend experience

---

## 1. Architecture Overview

The SmartMind system uses two Moodle components that work together:

```
local_sm_graphics_plugin (local plugin)     theme_smartmind (Boost child theme)
├── Enrollment API                          ├── Sidebar navigation
├── Custom pages (welcome, etc.)            ├── Portfolio layout (clean, no blocks)
├── Admin settings (colors, logo, toggle)   ├── SCSS styles (navbar, sidebar, hiding elements)
└── Update mechanism                        └── Inherits everything else from Boost
```

**How they connect:**
- Plugin pages call `$PAGE->set_pagelayout('portfolio')` → Moodle uses the theme's `layout/portfolio.php`
- Page content templates live in the plugin; layout/visual templates live in the theme
- Moodle auto-compiles theme SCSS — no manual `npx sass` needed

---

## 2. Project File Map

```
SM_Moodle_Graphic_Layer_Plugin/
│
│  ── Local plugin ──────────────────────────────────────────────────────────
├── version.php                             Plugin metadata and update server URL
├── lib.php                                 Enrollment API function
├── settings.php                            Admin settings UI (colors, logo, toggle, updates)
├── update.xml                              GitHub update manifest
│
├── pages/
│   └── welcome.php                         Welcome page (uses portfolio layout)
│
├── templates/
│   └── welcome_page.mustache               Welcome page content template
│
├── lang/en/
│   └── local_sm_graphics_plugin.php        All UI text strings
│
├── classes/                                (reserved for future PHP classes)
│
│  ── Theme ─────────────────────────────────────────────────────────────────
├── theme_smartmind/
│   ├── version.php                         Theme metadata, depends on Boost
│   ├── config.php                          Parent: Boost, layouts, SCSS callbacks
│   ├── lib.php                             SCSS callback functions
│   │
│   ├── layout/
│   │   └── portfolio.php                   Clean full-width layout with sidebar
│   │
│   ├── scss/
│   │   └── custom.scss                     All theme styles (navbar, sidebar, etc.)
│   │
│   ├── templates/
│   │   └── sidebar.mustache                Sidebar navigation template
│   │
│   └── lang/en/
│       └── theme_smartmind.php             Theme language strings
│
│  ── Repository files ──────────────────────────────────────────────────────
├── GUIDE.md                                This file
├── README.md                               Project overview
└── sm_graphics_plugin.zip                  Distributable ZIP (plugin + theme)
```

---

## 3. How to Add a New Page

**Step 1 — Create the PHP page** `pages/your_page.php`:

```php
<?php
require_once(__DIR__ . '/../../../config.php');
require_login();

global $CFG, $USER, $OUTPUT, $PAGE;

$PAGE->set_url(new moodle_url('/local/sm_graphics_plugin/pages/your_page.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('your_page_title', 'local_sm_graphics_plugin'));
$PAGE->set_heading(get_string('your_page_heading', 'local_sm_graphics_plugin'));
$PAGE->set_pagelayout('portfolio'); // Uses theme's clean layout with sidebar

echo $OUTPUT->header();
echo $OUTPUT->render_from_template('local_sm_graphics_plugin/your_page', [
    'username' => fullname($USER),
    'siteurl'  => $CFG->wwwroot,
    // Add any data your template needs here.
]);
echo $OUTPUT->footer();
```

**Step 2 — Create the template** `templates/your_page.mustache`:

```mustache
<div class="p-4">
    <h2>Hello, {{ username }}!</h2>
    <p>Your page content here.</p>
    <a href="{{ siteurl }}/my/" class="btn btn-primary">Dashboard</a>
</div>
```

**Step 3 — Add language strings** to `lang/en/local_sm_graphics_plugin.php`:

```php
$string['your_page_title']   = 'Your Page';
$string['your_page_heading'] = 'Your Page Heading';
```

**Step 4 — Deploy and purge caches.**

---

## 4. How to Edit Existing Pages

- **Change HTML structure:** Edit the `.mustache` template file
- **Change data passed to template:** Edit the `.php` page file (the array passed to `render_from_template`)
- **Always purge caches** after template changes

---

## 5. How to Edit the Sidebar

The sidebar is owned by the theme, not the plugin.

- **Change sidebar links:** Edit `theme_smartmind/layout/portfolio.php` — modify the `$sidebarcontext['menulinks']` array
- **Change sidebar HTML:** Edit `theme_smartmind/templates/sidebar.mustache`
- **Change sidebar styles:** Edit `theme_smartmind/scss/custom.scss` — look for the `.sm-sidebar` section

Always purge caches after changes.

---

## 6. How to Hide Moodle Elements

Add CSS rules to `theme_smartmind/scss/custom.scss`:

```scss
// Hide a specific block
.block_data_privacy { display: none !important; }

// Hide a nav item
.nav-item.specific-class { display: none !important; }
```

Purge caches after SCSS changes — Moodle recompiles automatically.

---

## 7. How to Change Colors/Styles

Edit `theme_smartmind/scss/custom.scss`. No manual compilation needed — Moodle handles it.

```scss
// Change navbar color
.navbar { background-color: #your-color !important; }

// Change sidebar background
.sm-sidebar { background-color: #your-color; }
```

Purge caches after changes.

---

## 8. How to Add New Functionality

Add functions to `lib.php` or create new classes in `classes/`. Follow Moodle API standards.

Example: the enrollment function in `lib.php`:
```php
local_sm_graphics_plugin_enroll_user($userid, $courseid, $roleid);
```

---

## 9. Deployment

### Deploy both components to Docker

```bash
cd ~/SM_Moodle_Graphic_Layer_Plugin && \
sudo docker cp . iomad_app:/var/www/html/local/sm_graphics_plugin/ && \
sudo docker cp theme_smartmind/. iomad_app:/var/www/html/theme/smartmind/ && \
sudo docker exec iomad_app php /var/www/html/admin/cli/upgrade.php --non-interactive && \
sudo docker exec iomad_app php /var/www/html/admin/cli/purge_caches.php
```

### Activate the theme

Site Administration → Appearance → Theme selector → SmartMind

### When to run upgrade vs purge caches

- **Version bump / new files:** Run `upgrade.php` + `purge_caches.php`
- **Template or SCSS only:** Run `purge_caches.php` only

### Production (ZIP)

1. Extract `sm_graphics_plugin.zip`
2. Copy the plugin files to `/local/sm_graphics_plugin/`
3. Copy `theme_smartmind/` to `/theme/smartmind/`
4. Run the Moodle upgrade — the plugin automatically activates the theme

---

## 10. Development Workflow

```
Change a page template     → purge caches → refresh browser
Change a page PHP file     → purge caches → refresh browser
Change theme SCSS          → purge caches → refresh browser (Moodle recompiles)
Change sidebar template    → purge caches → refresh browser
Add a new page             → deploy + upgrade → purge caches → refresh
```

**Purge caches:**
```bash
sudo docker exec iomad_app php /var/www/html/admin/cli/purge_caches.php
```
Or via UI: Site Administration → Development → Purge all caches

---

## 11. Releases and Auto-Update

The plugin uses a GitHub-hosted `update.xml` to notify Moodle admins of new versions.

### When releasing a new version:

1. Edit `version.php` — increment `$plugin->version` (YYYYMMDDXX) and `$plugin->release`
2. Edit `update.xml` — update `<version>`, `<release>`, `<download>`, and `<releasenotes>`
3. Create a GitHub Release at the matching tag with the plugin ZIP attached
4. Push `version.php` and `update.xml` to the `main` branch

Moodle periodically fetches `update.xml` from the GitHub raw URL. If the version there is higher than what is installed, Moodle shows "Update available" in Site Administration.
