<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * SM Graphic Layer Plugin - library functions.
 *
 * @package    local_sm_graphics_plugin
 * @copyright  2026 SmartMind Technologies
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Enrol a user into a course using the manual enrolment plugin.
 *
 * @param int $userid  The ID of the user to enrol.
 * @param int $courseid The ID of the course.
 * @param int $roleid  The role to assign (default 5 = student).
 * @return bool True on success, false if manual enrolment is unavailable.
 */
function local_sm_graphics_plugin_enroll_user(int $userid, int $courseid, int $roleid = 5): bool {
    global $DB;

    $enrol = enrol_get_plugin('manual');
    if (!$enrol) {
        return false;
    }

    $instances = $DB->get_records('enrol', [
        'courseid' => $courseid,
        'enrol'    => 'manual',
        'status'   => ENROL_INSTANCE_ENABLED,
    ]);
    if (empty($instances)) {
        return false;
    }

    $enrol->enrol_user(reset($instances), $userid, $roleid);
    return true;
}
